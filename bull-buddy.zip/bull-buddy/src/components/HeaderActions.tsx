import { View, Text, Pressable, StyleSheet } from 'react-native';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { colors, fonts, radius } from '../constants/theme';
import { useGameStore } from '../store/gameStore';

export default function HeaderActions() {
  const router = useRouter();
  const streakCount = useGameStore(s => s.streakCount);
  const coins = useGameStore(s => s.coins);

  return (
    <View style={styles.row}>
      <Pressable onPress={() => router.push('/modal/streak')} style={styles.btn}>
        <Ionicons name="flame" size={16} color={colors.coral} />
        <Text style={styles.btnText}>{streakCount}</Text>
      </Pressable>
      <Pressable onPress={() => router.push('/modal/logros')} style={styles.btn}>
        <Ionicons name="trophy" size={16} color={colors.yellow} />
      </Pressable>
      <Pressable onPress={() => router.push('/modal/tienda')} style={styles.btn}>
        <Ionicons name="cart" size={16} color={colors.purple} />
      </Pressable>
      <Pressable onPress={() => router.push('/modal/ranking')} style={styles.btn}>
        <Ionicons name="podium" size={16} color={colors.blue} />
      </Pressable>
      <Pressable onPress={() => router.push('/modal/amigos')} style={styles.btn}>
        <Ionicons name="people" size={15} color={colors.purple} />
      </Pressable>
      <Pressable onPress={() => router.push('/modal/eventos')} style={styles.btn}>
        <Ionicons name="calendar" size={14} color={colors.coral} />
      </Pressable>
      <Pressable onPress={() => router.push('/chat')} style={styles.btn}>
        <Ionicons name="chatbubble" size={15} color={colors.green} />
      </Pressable>
      <View style={[styles.btn, styles.coinBtn]}>
        <Ionicons name="wallet" size={14} color={colors.yellow} />
        <Text style={styles.coinText}>{coins}</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: 'row', gap: 6, alignItems: 'center' },
  btn: {
    width: 32, height: 32, borderRadius: radius.full,
    backgroundColor: colors.bgCard, alignItems: 'center', justifyContent: 'center',
    flexDirection: 'row', gap: 2,
  },
  btnText: { fontSize: 11, fontWeight: '700', color: colors.coral },
  coinBtn: { width: 'auto', paddingHorizontal: 10, gap: 4 },
  coinText: { fontSize: fonts.sizes.xs, fontWeight: '700', color: colors.text },
});
