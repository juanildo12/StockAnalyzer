import { useState, useCallback, useRef, useEffect } from 'react';
import { View, Text, StyleSheet, SafeAreaView, Pressable, ScrollView, Animated } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors, fonts, radius, shadows } from '../constants/theme';
import { useGameStore } from '../store/gameStore';
import MascotBubble from '../components/MascotBubble';
import HeaderActions from '../components/HeaderActions';
import { QUIZ_QUESTIONS } from '../data/quizQuestions';
import { hapticsSuccess, hapticsError, hapticsLight } from '../utils/haptics';
import { playSound } from '../utils/sounds';
import { checkAchievements } from '../utils/achievements';
import { useUIStore } from '../store/uiStore';
import { getDifficultyProfile } from '../utils/adaptiveDifficulty';
import type { QuizDifficulty, MascotMood } from '../types';

const DIFFICULTIES: { id: QuizDifficulty; label: string; color: string }[] = [
  { id: 'facil', label: 'Fácil', color: colors.green },
  { id: 'intermedio', label: 'Intermedio', color: colors.yellow },
  { id: 'avanzado', label: 'Avanzado', color: colors.coral },
];

function shuffleArray<T>(arr: T[]): T[] {
  return [...arr].sort(() => Math.random() - 0.5);
}

const COMBO_COLORS = ['', colors.green, colors.yellow, colors.coral, colors.purple, colors.blue];

function ComboBadge({ combo }: { combo: number }) {
  return (
    <View style={[styles.comboBadge, { backgroundColor: COMBO_COLORS[Math.min(combo, COMBO_COLORS.length - 1)] }]}>
      <Text style={styles.comboEmoji}>🔥</Text>
      <Text style={styles.comboText}>x{combo}</Text>
    </View>
  );
}

function OptionButton({
  text, index, correctIndex, selectedAnswer, answered, onPress,
}: {
  text: string; index: number; correctIndex: number; selectedAnswer: number | null;
  answered: boolean; onPress: () => void;
}) {
  const scaleAnim = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    if (answered) {
      Animated.spring(scaleAnim, { toValue: 1, friction: 5, useNativeDriver: true }).start();
    }
  }, [answered]);

  let bgColor = colors.bgCard;
  let borderColor = colors.border;
  let textColor = colors.text;

  if (answered) {
    if (index === correctIndex) {
      bgColor = colors.greenLight;
      borderColor = colors.green;
      textColor = colors.green;
    } else if (index === selectedAnswer && index !== correctIndex) {
      bgColor = colors.coralLight;
      borderColor = colors.coral;
      textColor = colors.coral;
    }
  }

  return (
    <Animated.View style={{ transform: [{ scale: scaleAnim }] }}>
      <Pressable onPress={onPress} style={[styles.optionBtn, { backgroundColor: bgColor, borderColor }]} disabled={answered}>
        <View style={[styles.optionRadio,
          answered && index === correctIndex && { backgroundColor: colors.green },
          answered && index === selectedAnswer && index !== correctIndex && { backgroundColor: colors.coral }]}>
          {answered && index === correctIndex && <Ionicons name="checkmark" size={12} color={colors.white} />}
          {answered && index === selectedAnswer && index !== correctIndex && <Ionicons name="close" size={12} color={colors.white} />}
          {!answered && selectedAnswer === index && <View style={styles.radioInner} />}
        </View>
        <Text style={[styles.optionText, { color: textColor }]}>{text}</Text>
      </Pressable>
    </Animated.View>
  );
}

export default function AprendeScreen() {
  const { completedQuizIds, earnXP, earnCoins, completeQuiz, quizCombo, incrementQuizCombo, resetQuizCombo, addQuizResult, lastQuizResults } = useGameStore();
  const [selectedDifficulty, setSelectedDifficulty] = useState<QuizDifficulty | null>(null);
  const [activeQuestions, setActiveQuestions] = useState<typeof QUIZ_QUESTIONS>([]);
  const [currentQIdx, setCurrentQIdx] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [answered, setAnswered] = useState(false);
  const [score, setScore] = useState(0);
  const [sessionDone, setSessionDone] = useState(false);
  const [mascotText, setMascotText] = useState('¡Elige un nivel y pon a prueba tus conocimientos!');
  const [mascotMood, setMascotMood] = useState<MascotMood>('feliz');
  const comboPulse = useRef(new Animated.Value(1)).current;
  const { addToast, triggerConfetti } = useUIStore();
  const prevLevel = useRef(useGameStore.getState().level);
  const diffProfile = getDifficultyProfile(lastQuizResults, []);

  useEffect(() => {
    if (quizCombo >= 2) {
      Animated.sequence([
        Animated.timing(comboPulse, { toValue: 1.3, duration: 150, useNativeDriver: true }),
        Animated.timing(comboPulse, { toValue: 1, duration: 150, useNativeDriver: true }),
      ]).start();
    }
  }, [quizCombo]);

  const currentQ = activeQuestions[currentQIdx];
  const totalQuestions = activeQuestions.length;

  const startQuiz = useCallback((diff: QuizDifficulty) => {
    const pool = QUIZ_QUESTIONS.filter(q => q.difficulty === diff && !completedQuizIds.includes(q.id));
    const questions = pool.length >= 5 ? shuffleArray(pool).slice(0, 5) : shuffleArray(QUIZ_QUESTIONS.filter(q => q.difficulty === diff)).slice(0, 5);
    resetQuizCombo();
    setSelectedDifficulty(diff);
    setActiveQuestions(questions);
    setCurrentQIdx(0);
    setSelectedAnswer(null);
    setAnswered(false);
    setScore(0);
    setSessionDone(false);
    setMascotText(`¡${questions.length} preguntas nivel ${diff}! Responde con cuidado.`);
    setMascotMood('emocionado');
  }, [completedQuizIds, resetQuizCombo]);

  const handleAnswer = (idx: number) => {
    if (answered || !currentQ) return;
    setSelectedAnswer(idx);
    setAnswered(true);

    const correct = idx === currentQ.correctIndex;
    addQuizResult({ correct, difficulty: currentQ.difficulty });

    if (correct) {
      incrementQuizCombo();
      const baseCoins = currentQ.difficulty === 'facil' ? 10 : currentQ.difficulty === 'intermedio' ? 20 : 30;
      const comboBonus = quizCombo * 5;
      const totalCoins = baseCoins + comboBonus;
      const xpEarned = currentQ.difficulty === 'facil' ? 15 : currentQ.difficulty === 'intermedio' ? 25 : 40;
      playSound('correct');
      earnCoins(totalCoins);
      earnXP(xpEarned);
      const newLevel = useGameStore.getState().level;
      if (newLevel > prevLevel.current) {
        playSound('levelup');
        triggerConfetti();
        addToast({ type: 'levelup', title: `¡Nivel ${newLevel}!`, icon: '⭐', coins: newLevel * 10 });
        prevLevel.current = newLevel;
      }
      if (quizCombo + 1 >= 3) {
        playSound('celebration');
        triggerConfetti();
        addToast({ type: 'combo', title: `🔥 Combo x${quizCombo + 1}!`, icon: '🔥', coins: comboBonus });
      }
      completeQuiz(currentQ.id);
      setScore(s => s + 1);
      const comboMsg = quizCombo >= 1 ? ` 🔥 Combo x${quizCombo + 1}! (+${comboBonus}🪙)` : '';
      setMascotText('¡Correcto!' + comboMsg + ' ' + currentQ.explanation.split('.')[0] + '.');
      setMascotMood('emocionado');
      hapticsSuccess();
      const newAchs = checkAchievements();
      newAchs.forEach(a => { playSound('celebration'); triggerConfetti(); addToast({ type: 'achievement', title: a.title, icon: a.icon, coins: a.coinsReward, xp: a.xpReward }); });
    } else {
      playSound('wrong');
      resetQuizCombo();
      setMascotText(currentQ.explanation);
      setMascotMood('pensativo');
      hapticsError();
      checkAchievements();
    }
  };

  const nextQuestion = () => {
    hapticsLight();
    if (currentQIdx < totalQuestions - 1) {
      setCurrentQIdx(i => i + 1);
      setSelectedAnswer(null);
      setAnswered(false);
      setMascotText('Siguiente pregunta...');
      setMascotMood('feliz');
    } else {
      setSessionDone(true);
      const reward = selectedDifficulty === 'facil' ? 20 : selectedDifficulty === 'intermedio' ? 30 : 50;
      earnCoins(reward);
      earnXP(reward);
      setMascotText(`¡Completaste la sesión! ${score}/${totalQuestions} correctas. +${reward}🪙 +${reward}XP`);
      setMascotMood(score >= totalQuestions * 0.7 ? 'emocionado' : 'feliz');
      hapticsSuccess();
    }
  };

  if (!selectedDifficulty) {
    return (
      <SafeAreaView style={styles.container}>
        <ScrollView contentContainerStyle={styles.scroll}>
          <View style={styles.header}>
            <Text style={styles.headerTitle}>🧠 Aprende</Text>
            <View style={styles.completedBadge}>
              <Ionicons name="checkmark-done" size={14} color={colors.green} />
              <Text style={styles.completedText}>{completedQuizIds.length} completados</Text>
            </View>
          </View>
          <HeaderActions />
          <MascotBubble text={mascotText} mood={mascotMood} />
          <Text style={styles.sectionTitle}>Elige tu nivel</Text>
          {DIFFICULTIES.map(diff => {
            const count = QUIZ_QUESTIONS.filter(q => q.difficulty === diff.id).length;
            const done = QUIZ_QUESTIONS.filter(q => q.difficulty === diff.id && completedQuizIds.includes(q.id)).length;
            const isRecommended = diff.id === diffProfile.recommendedDifficulty && lastQuizResults.length > 0;
            return (
              <Pressable key={diff.id} onPress={() => startQuiz(diff.id)} style={styles.diffCard}>
                <View style={[styles.diffIcon, { backgroundColor: `${diff.color}18` }]}>
                  <Ionicons name={diff.id === 'facil' ? 'leaf' : diff.id === 'intermedio' ? 'trending-up' : 'flame'} size={24} color={diff.color} />
                </View>
                <View style={{ flex: 1 }}>
                  <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
                    <Text style={styles.diffTitle}>{diff.label}</Text>
                    {isRecommended && (
                      <View style={[styles.recommendedBadge, { backgroundColor: diff.color }]}>
                        <Text style={styles.recommendedBadgeText}>Recomendado</Text>
                      </View>
                    )}
                  </View>
                  <Text style={styles.diffCount}>{done}/{count} preguntas</Text>
                </View>
                <Ionicons name="chevron-forward" size={20} color={colors.textMuted} />
              </Pressable>
            );
          })}
        </ScrollView>
      </SafeAreaView>
    );
  }

  if (!sessionDone && currentQ) {
    const diffColor = DIFFICULTIES.find(d => d.id === selectedDifficulty)?.color || colors.purple;
    return (
      <SafeAreaView style={styles.container}>
        <ScrollView contentContainerStyle={styles.scroll}>
          <View style={styles.quizHeader}>
            <Pressable onPress={() => setSelectedDifficulty(null)} style={styles.backBtn}>
              <Ionicons name="arrow-back" size={20} color={colors.textMuted} />
            </Pressable>
            <View style={styles.progressBar}>
              <View style={[styles.progressFill, { width: `${((currentQIdx + 1) / totalQuestions) * 100}%`, backgroundColor: diffColor }]} />
            </View>
            <Text style={styles.progressText}>{currentQIdx + 1}/{totalQuestions}</Text>
            {quizCombo >= 2 && (
              <Animated.View style={{ transform: [{ scale: comboPulse }] }}>
                <ComboBadge combo={quizCombo} />
              </Animated.View>
            )}
          </View>
          <MascotBubble text={mascotText} mood={mascotMood} />
          <View style={styles.questionCard}>
            <Text style={styles.questionText}>{currentQ.question}</Text>
            <View style={styles.optionsList}>
              {currentQ.options.map((opt, i) => (
                <OptionButton
                  key={i}
                  text={opt}
                  index={i}
                  correctIndex={currentQ.correctIndex}
                  selectedAnswer={selectedAnswer}
                  answered={answered}
                  onPress={() => handleAnswer(i)}
                />
              ))}
            </View>
            {quizCombo >= 2 && !answered && (
              <View style={styles.comboHint}>
                <Text style={styles.comboHintText}>🔥 Combo x{quizCombo} — ¡sigue así!</Text>
              </View>
            )}
            {answered && (
              <Pressable onPress={nextQuestion} style={[styles.nextBtn, { backgroundColor: diffColor }]}>
                <Text style={styles.nextBtnText}>
                  {currentQIdx < totalQuestions - 1 ? 'Siguiente →' : 'Ver resultados'}
                </Text>
              </Pressable>
            )}
          </View>
        </ScrollView>
      </SafeAreaView>
    );
  }

  const pct = Math.round((score / totalQuestions) * 100);
  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.scroll}>
        <View style={styles.resultCard}>
          <View style={[styles.resultCircle, { borderColor: pct >= 70 ? colors.green : pct >= 40 ? colors.yellow : colors.coral }]}>
            <Text style={[styles.resultScore, { color: pct >= 70 ? colors.green : pct >= 40 ? colors.yellow : colors.coral }]}>
              {score}/{totalQuestions}
            </Text>
          </View>
          <Text style={styles.resultTitle}>¡{pct >= 70 ? 'Buen trabajo!' : pct >= 40 ? 'Sigue practicando' : 'Ánimo!'}</Text>
          <MascotBubble text={mascotText} mood={mascotMood} />
          <Pressable onPress={() => setSelectedDifficulty(null)} style={styles.newQuizBtn}>
            <Text style={styles.newQuizBtnText}>Elegir otro nivel</Text>
          </Pressable>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.bg },
  scroll: { padding: 16, gap: 12 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  headerTitle: { fontSize: fonts.sizes.xl, fontWeight: '800', color: colors.text },
  completedBadge: { flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: colors.greenLight, paddingHorizontal: 10, paddingVertical: 5, borderRadius: radius.full },
  completedText: { fontSize: fonts.sizes.xs, color: colors.green, fontWeight: '600' },
  sectionTitle: { fontSize: fonts.sizes.md, fontWeight: '700', color: colors.text },
  diffCard: { flexDirection: 'row', alignItems: 'center', backgroundColor: colors.bgCard, borderRadius: radius.xl, padding: 16, gap: 14, ...shadows.card },
  diffIcon: { width: 48, height: 48, borderRadius: radius.lg, alignItems: 'center', justifyContent: 'center' },
  diffTitle: { color: colors.text, fontWeight: '700', fontSize: fonts.sizes.md },
  diffCount: { color: colors.textMuted, fontSize: fonts.sizes.sm, marginTop: 2 },
  quizHeader: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  backBtn: { width: 36, height: 36, borderRadius: radius.lg, backgroundColor: colors.bgCard, alignItems: 'center', justifyContent: 'center' },
  progressBar: { flex: 1, height: 8, backgroundColor: colors.bgCard, borderRadius: 4, overflow: 'hidden' },
  progressFill: { height: '100%', borderRadius: 4 },
  progressText: { fontSize: fonts.sizes.sm, fontWeight: '600', color: colors.textMuted },
  comboBadge: { flexDirection: 'row', alignItems: 'center', gap: 3, paddingHorizontal: 10, paddingVertical: 5, borderRadius: radius.full },
  comboEmoji: { fontSize: 14 },
  comboText: { color: colors.white, fontWeight: '800', fontSize: fonts.sizes.sm },
  comboHint: { backgroundColor: colors.yellowLight, paddingVertical: 8, paddingHorizontal: 12, borderRadius: radius.lg, alignItems: 'center' },
  comboHintText: { color: colors.text, fontWeight: '700', fontSize: fonts.sizes.sm },
  questionCard: { backgroundColor: colors.bgCard, borderRadius: radius.xl, padding: 20, gap: 16, ...shadows.card },
  questionText: { color: colors.text, fontSize: fonts.sizes.lg, fontWeight: '700', lineHeight: 26 },
  optionsList: { gap: 10 },
  optionBtn: { flexDirection: 'row', alignItems: 'center', gap: 12, padding: 14, borderRadius: radius.lg, borderWidth: 2 },
  optionRadio: { width: 22, height: 22, borderRadius: radius.full, borderWidth: 2, borderColor: colors.border, alignItems: 'center', justifyContent: 'center' },
  radioInner: { width: 10, height: 10, borderRadius: 5, backgroundColor: colors.purple },
  optionText: { flex: 1, fontSize: fonts.sizes.md, lineHeight: 22 },
  nextBtn: { paddingVertical: 14, borderRadius: radius.lg, alignItems: 'center' },
  nextBtnText: { color: colors.white, fontWeight: '700', fontSize: fonts.sizes.md },
  resultCard: { alignItems: 'center', padding: 32, backgroundColor: colors.bgCard, borderRadius: radius.xl, gap: 16, ...shadows.card },
  resultCircle: { width: 90, height: 90, borderRadius: 45, borderWidth: 4, alignItems: 'center', justifyContent: 'center', marginBottom: 8 },
  resultScore: { fontSize: fonts.sizes.xl, fontWeight: '800' },
  resultTitle: { fontSize: fonts.sizes.xl, fontWeight: '700', color: colors.text },
  newQuizBtn: { paddingVertical: 14, paddingHorizontal: 32, borderRadius: radius.lg, backgroundColor: colors.purpleLight, borderWidth: 1, borderColor: colors.purple },
  newQuizBtnText: { color: colors.purple, fontWeight: '700', fontSize: fonts.sizes.md },
  recommendedBadge: { paddingHorizontal: 8, paddingVertical: 2, borderRadius: radius.full },
  recommendedBadgeText: { color: colors.white, fontSize: 9, fontWeight: '700' },
});
